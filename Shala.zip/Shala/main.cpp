#include "Profile.h"
int main(){
	Profile p1;
	p1.displayProfile();
}
